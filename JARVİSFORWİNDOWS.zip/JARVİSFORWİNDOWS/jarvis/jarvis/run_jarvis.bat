@echo off
title JARVIS
cd /d "%~dp0"
set TEMP=D:\Python\temp
set TMP=D:\Python\temp
if not exist "%TEMP%" mkdir "%TEMP%"

set PY=D:\Python\venvs\jarvis\Scripts\python.exe
if not exist "%PY%" set PY=%~dp0.venv\Scripts\python.exe
if not exist "%PY%" set PY=python

echo JARVIS baslatiliyor...
"%PY%" main.py
if errorlevel 1 pause
