"""
TTS (Text-to-Speech) — Windows SAPI (pyttsx3).
Alp Ünlü tarafından yapılmıştır — @alppunlu
"""

import threading

_engine = None
_engine_lock = threading.Lock()


def _get_engine():
    global _engine
    with _engine_lock:
        if _engine is None:
            import pyttsx3

            _engine = pyttsx3.init()
            for voice in _engine.getProperty("voices"):
                name = (voice.name or "").lower()
                lang = "".join(getattr(voice, "languages", []) or []).lower()
                if "turk" in name or "tr" in lang or "tur" in lang:
                    _engine.setProperty("voice", voice.id)
                    break
            rate = _engine.getProperty("rate")
            if rate:
                _engine.setProperty("rate", max(120, int(rate * 0.95)))
        return _engine


def speak_text(text: str, on_done=None, blocking: bool = False):
    if not text or not text.strip():
        if on_done:
            on_done()
        return

    max_len = 500
    if len(text) > max_len:
        text = text[:max_len] + "..."

    def _run():
        try:
            engine = _get_engine()
            engine.say(text)
            engine.runAndWait()
        except Exception:
            pass
        if on_done:
            on_done()

    if blocking:
        _run()
    else:
        threading.Thread(target=_run, daemon=True).start()


def get_available_voices() -> list[str]:
    try:
        import pyttsx3

        engine = pyttsx3.init()
        return [voice.name for voice in engine.getProperty("voices")]
    except Exception:
        return []
