"""
Medya oynatma — YouTube, Spotify Desktop (Windows).
Alp Ünlü tarafından yapılmıştır — @alppunlu
"""

from __future__ import annotations

import os
import time
import urllib.parse
from pathlib import Path

from actions.browser import browser_control
from platform_win import app_exists_win, hotkey, open_url, press_key


SPOTIFY_PATHS = [
    Path(r"C:\Users") / "AppData" / "Roaming" / "Spotify" / "Spotify.exe",
    Path(r"C:\Program Files\WindowsApps"),
]
SPOTIFY_EXE = ["Spotify.exe", "spotify"]


def _play_youtube(query: str) -> str:
    return browser_control("play_youtube", query=query)


def _play_spotify(query: str, autoplay: bool = True) -> str:
    if not app_exists_win(SPOTIFY_EXE, [Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "WindowsApps"]):
        # Still try spotify: URI
        pass

    encoded_query = urllib.parse.quote(query.strip())
    search_url = f"spotify:search:{encoded_query}"

    try:
        open_url(search_url)
    except Exception as exc:
        return f"Spotify açılamadı: {exc}"

    if not autoplay:
        return f"Spotify içinde '{query}' araması açıldı."

    time.sleep(2.0)
    ok, detail = hotkey("tab", delay=0.2)
    if not ok:
        return f"Spotify araması açıldı ama otomatik oynatma tamamlanamadı: {detail}"
    press_key("down", delay=0.2)
    press_key("enter", delay=0.3)
    press_key("space", delay=0.2)
    return f"Spotify'da oynatılıyor: {query}"


def play_media(query: str, provider: str = "auto", autoplay: bool = True) -> str:
    if not query or not query.strip():
        return "Çalınacak içerik belirtilmedi."

    normalized_provider = (provider or "auto").strip().lower()
    if normalized_provider in {"yt", "youtube music"}:
        normalized_provider = "youtube"
    elif normalized_provider in {"apple music", "music", "apple_music"}:
        normalized_provider = "youtube_music"

    if normalized_provider == "spotify":
        return _play_spotify(query, autoplay=autoplay)
    if normalized_provider in {"youtube", "youtube_music"}:
        if normalized_provider == "youtube_music":
            search_url = f"https://music.youtube.com/search?q={urllib.parse.quote(query.strip())}"
            open_url(search_url)
            return f"YouTube Music'te arama açıldı: {query}"
        return _play_youtube(query)

    local_spotify = Path(os.environ.get("APPDATA", "")) / "Spotify" / "Spotify.exe"
    if local_spotify.exists() or app_exists_win(SPOTIFY_EXE):
        result = _play_spotify(query, autoplay=autoplay)
        if "açılamadı" not in result.lower():
            return result
    return _play_youtube(query)
