"""
Windows takvim ve anımsatıcı backend — Microsoft Outlook (COM).
Alp Ünlü tarafından yapılmıştır — @alppunlu
"""

from __future__ import annotations

import datetime as dt
import json
from typing import Any

OL_FOLDER_CALENDAR = 9
OL_FOLDER_TASKS = 13
OL_APPOINTMENT = 1
OL_TASK = 3


def _outlook():
    import win32com.client

    return win32com.client.Dispatch("Outlook.Application")


def _json_ok(**fields: Any) -> str:
    return json.dumps({"ok": True, **fields}, ensure_ascii=False)


def _json_err(detail: str, **fields: Any) -> str:
    return json.dumps({"ok": False, "detail": detail, "error": detail, **fields}, ensure_ascii=False)


def _outlook_dt(value: dt.datetime) -> str:
    return value.strftime("%m/%d/%Y %H:%M %p")


def _parse_iso(value: str) -> dt.datetime | None:
    raw = (value or "").strip()
    if not raw:
        return None
    if raw.endswith("Z"):
        try:
            return dt.datetime.fromisoformat(raw.replace("Z", "+00:00")).replace(tzinfo=None)
        except ValueError:
            pass
    try:
        return dt.datetime.fromisoformat(raw)
    except ValueError:
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return dt.datetime.strptime(raw, fmt)
        except ValueError:
            continue
    return None


def _com_to_ts(value) -> int:
    if value is None:
        return 0
    if isinstance(value, dt.datetime):
        return int(value.timestamp())
    try:
        return int(value.timestamp())
    except Exception:
        pass
    try:
        return int(dt.datetime.fromtimestamp(float(value)).timestamp())
    except Exception:
        return 0


def _event_from_appointment(item) -> dict:
    start_ts = _com_to_ts(getattr(item, "Start", None))
    end_ts = _com_to_ts(getattr(item, "End", None)) or start_ts

    all_day = bool(getattr(item, "AllDayEvent", False))
    return {
        "start_ts": start_ts,
        "end_ts": end_ts,
        "calendar": str(getattr(item, "Parent", "") or ""),
        "title": str(getattr(item, "Subject", "") or "Adsiz etkinlik").strip(),
        "location": str(getattr(item, "Location", "") or "").strip(),
        "all_day": all_day,
    }


def _fetch_events(start: dt.datetime, end: dt.datetime) -> tuple[bool, str, list[dict]]:
    try:
        outlook = _outlook()
        namespace = outlook.GetNamespace("MAPI")
        calendar = namespace.GetDefaultFolder(OL_FOLDER_CALENDAR)
        items = calendar.Items
        items.IncludeRecurrences = True
        items.Sort("[Start]")
        restriction = (
            f"[Start] >= '{_outlook_dt(start)}' AND [Start] < '{_outlook_dt(end)}'"
        )
        filtered = items.Restrict(restriction)
        events: list[dict] = []
        item = filtered.GetFirst()
        while item:
            try:
                if int(getattr(item, "Class", 0)) == OL_APPOINTMENT:
                    events.append(_event_from_appointment(item))
            except Exception:
                pass
            item = filtered.GetNext()
        return True, "", events
    except Exception as exc:
        return False, f"Outlook takvimi okunamadi: {exc}", []


def _window_for_mode(mode: str, payload: dict | None) -> tuple[dt.datetime, dt.datetime]:
    now = dt.datetime.now()
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)

    if mode == "tomorrow":
        start = today + dt.timedelta(days=1)
        return start, start + dt.timedelta(days=1)
    if mode == "week":
        return today, today + dt.timedelta(days=7)
    if mode == "agenda":
        return now, now + dt.timedelta(days=14)
    if mode == "next":
        return now, now + dt.timedelta(days=365)
    if mode == "range" and payload:
        start = _parse_iso(str(payload.get("start_iso", "")))
        end = _parse_iso(str(payload.get("end_iso", "")))
        if start and end:
            return start, end
    return today, today + dt.timedelta(days=1)


def _reminder_from_task(item) -> dict:
    due = getattr(item, "DueDate", None)
    due_ts = 0
    if due and str(due) not in {"", "4501-01-01 00:00:00"}:
        due_ts = _com_to_ts(due)

    priority = int(getattr(item, "Importance", 0) or 0)
    return {
        "title": str(getattr(item, "Subject", "") or "Adsiz animsatici").strip(),
        "list_name": str(getattr(item, "Categories", "") or "").strip(),
        "notes": str(getattr(item, "Body", "") or "").strip()[:200],
        "completed": bool(getattr(item, "Complete", False)),
        "priority": 1 if priority >= 2 else 0,
        "due_ts": due_ts,
        "all_day": due_ts > 0 and getattr(item, "DueDate", None) and not getattr(item, "DueTime", None),
    }


def _fetch_reminders(query: str, limit: int, list_name: str) -> tuple[bool, str, list[dict]]:
    try:
        outlook = _outlook()
        namespace = outlook.GetNamespace("MAPI")
        tasks = namespace.GetDefaultFolder(OL_FOLDER_TASKS)
        items = tasks.Items
        items.Sort("[DueDate]")
        reminders: list[dict] = []
        now = dt.datetime.now()
        today = now.date()

        item = items.GetFirst()
        while item:
            try:
                if int(getattr(item, "Class", 0)) != OL_TASK:
                    item = items.GetNext()
                    continue
                if bool(getattr(item, "Complete", False)):
                    item = items.GetNext()
                    continue
                rec = _reminder_from_task(item)
                if list_name and list_name.lower() not in rec["list_name"].lower():
                    item = items.GetNext()
                    continue

                due_ts = rec["due_ts"]
                due_date = dt.datetime.fromtimestamp(due_ts).date() if due_ts > 0 else None

                if query == "today" and due_date != today:
                    item = items.GetNext()
                    continue
                if query == "overdue" and (not due_date or due_date >= today):
                    item = items.GetNext()
                    continue
                if query == "next":
                    reminders.append(rec)
                    break

                reminders.append(rec)
            except Exception:
                pass
            item = items.GetNext()

        reminders.sort(key=lambda r: (r["due_ts"] <= 0, r["due_ts"] or 0, r["title"].lower()))
        if query == "next":
            return True, "", reminders[:1]
        return True, "", reminders[:limit]
    except Exception as exc:
        return False, f"Outlook gorevleri okunamadi: {exc}", []


def run_helper(mode: str, payload: dict | None = None) -> tuple[bool, str]:
    mode = (mode or "today").strip()
    payload = payload or {}

    if mode == "reminders_list":
        query = str(payload.get("query", "upcoming")).strip().lower() or "upcoming"
        limit = max(1, min(20, int(payload.get("limit", 8) or 8)))
        list_name = str(payload.get("list_name", "") or "").strip()
        ok, detail, reminders = _fetch_reminders(query, limit, list_name)
        if not ok:
            return False, detail
        return True, _json_ok(reminders=reminders)

    if mode == "create_reminder":
        title = str(payload.get("title", "") or "").strip()
        if not title:
            return False, "Animsatici basligi gerekli."
        try:
            outlook = _outlook()
            task = outlook.CreateItem(OL_TASK)
            task.Subject = title
            notes = str(payload.get("notes", "") or "").strip()
            if notes:
                task.Body = notes
            list_name = str(payload.get("list_name", "") or "").strip()
            if list_name:
                task.Categories = list_name
            due_iso = str(payload.get("due_iso", "") or "").strip()
            if due_iso:
                due = _parse_iso(due_iso)
                if due:
                    task.DueDate = due
            priority = str(payload.get("priority", "") or "").strip().lower()
            if priority in {"high", "yuksek", "1"}:
                task.Importance = 2
            task.Save()
            created = _reminder_from_task(task)
            return True, _json_ok(created=created)
        except Exception as exc:
            return False, f"Animsatici eklenemedi: {exc}"

    if mode == "create_event":
        title = str(payload.get("title", "") or "").strip()
        start_iso = str(payload.get("start_iso", "") or "").strip()
        if not title or not start_iso:
            return False, "Etkinlik basligi ve baslangic zamani gerekli."
        start = _parse_iso(start_iso)
        if not start:
            return False, "Baslangic tarihi gecersiz."
        end_iso = str(payload.get("end_iso", "") or "").strip()
        end = _parse_iso(end_iso) if end_iso else start + dt.timedelta(hours=1)
        if not end:
            end = start + dt.timedelta(hours=1)
        try:
            outlook = _outlook()
            appt = outlook.CreateItem(OL_APPOINTMENT)
            appt.Subject = title
            appt.Start = start
            appt.End = end
            appt.AllDayEvent = bool(payload.get("all_day", False))
            location = str(payload.get("location", "") or "").strip()
            if location:
                appt.Location = location
            notes = str(payload.get("notes", "") or "").strip()
            if notes:
                appt.Body = notes
            appt.Save()
            return True, _json_ok(created=_event_from_appointment(appt))
        except Exception as exc:
            return False, f"Takvim etkinligi eklenemedi: {exc}"

    if mode == "delete_event":
        title = str(payload.get("title", "") or "").strip()
        if not title:
            return False, "Silinecek etkinlik basligi gerekli."
        start, end = dt.datetime.now() - dt.timedelta(days=365), dt.datetime.now() + dt.timedelta(days=365)
        ok, detail, events = _fetch_events(start, end)
        if not ok:
            return False, detail
        needle = title.lower()
        matches = [e for e in events if needle in e["title"].lower()]
        if not matches:
            return False, f"'{title}' ile eslesen etkinlik bulunamadi."
        try:
            outlook = _outlook()
            namespace = outlook.GetNamespace("MAPI")
            calendar = namespace.GetDefaultFolder(OL_FOLDER_CALENDAR)
            items = calendar.Items
            item = items.GetFirst()
            deleted = None
            while item:
                try:
                    if int(getattr(item, "Class", 0)) == OL_APPOINTMENT:
                        subj = str(getattr(item, "Subject", "") or "")
                        if needle in subj.lower():
                            ev = _event_from_appointment(item)
                            item.Delete()
                            deleted = ev
                            if not bool(payload.get("delete_all_matches", False)):
                                break
                except Exception:
                    pass
                item = items.GetNext()
            if deleted:
                return True, _json_ok(deleted=deleted)
            return False, "Etkinlik silinemedi."
        except Exception as exc:
            return False, f"Takvim etkinligi silinemedi: {exc}"

    start, end = _window_for_mode(mode, payload)
    ok, detail, events = _fetch_events(start, end)
    if not ok:
        return False, detail

    if mode == "next":
        now_ts = int(dt.datetime.now().timestamp())
        events = [e for e in events if e["end_ts"] >= now_ts]
        events.sort(key=lambda e: (e["start_ts"], e["title"].lower()))

    return True, _json_ok(events=events)
