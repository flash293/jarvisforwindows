"""
Uygulama açma — Windows start / os.startfile.
Alp Ünlü tarafından yapılmıştır — @alppunlu
"""

import subprocess
import sys

from platform_win import find_executable, open_app_by_name


APP_ALIASES = {
    "safari": "msedge",
    "chrome": "chrome",
    "google chrome": "chrome",
    "firefox": "firefox",
    "edge": "msedge",
    "microsoft edge": "msedge",
    "terminal": "wt",
    "windows terminal": "wt",
    "cmd": "cmd",
    "powershell": "powershell",
    "explorer": "explorer",
    "dosya gezgini": "explorer",
    "finder": "explorer",
    "spotify": "spotify",
    "vscode": "code",
    "vs code": "code",
    "visual studio code": "code",
    "code": "code",
    "notion": "notion",
    "slack": "slack",
    "discord": "Discord",
    "whatsapp": "WhatsApp",
    "telegram": "Telegram",
    "zoom": "zoom",
    "mail": "outlook",
    "outlook": "outlook",
    "calendar": "outlook",
    "takvim": "outlook",
    "notes": "notepad",
    "notlar": "notepad",
    "music": "ms-windows-store://pdp/?productid=9WZDNCRFJ3Q2",
    "müzik": "ms-windows-store://pdp/?productid=9WZDNCRFJ3Q2",
    "photos": "ms-photos:",
    "fotoğraflar": "ms-photos:",
    "maps": "bingmaps:",
    "haritalar": "bingmaps:",
    "calculator": "calc",
    "hesap makinesi": "calc",
    "system preferences": "ms-settings:",
    "system settings": "ms-settings:",
    "ayarlar": "ms-settings:",
    "activity monitor": "taskmgr",
    "aktivite monitörü": "taskmgr",
    "görev yöneticisi": "taskmgr",
    "task manager": "taskmgr",
    "preview": "ms-photos:",
    "önizleme": "ms-photos:",
    "notepad": "notepad",
    "figma": "figma",
    "postman": "postman",
    "docker": "docker desktop",
    "tableplus": "tableplus",
    "xcode": "devenv",
}


def open_app(app_name: str) -> str:
    if not app_name:
        return "Uygulama adı belirtilmedi."

    if sys.platform != "win32":
        return "open_app yalnizca Windows icin yapilandirildi."

    normalized = app_name.lower().strip()
    resolved = APP_ALIASES.get(normalized, app_name)

    exe_path = find_executable([resolved, resolved + ".exe", app_name, app_name + ".exe"])
    target = exe_path or resolved

    try:
        ok, detail = open_app_by_name(target)
        if ok:
            return f"{app_name} açıldı."
        return f"'{app_name}' açılamadı: {detail}"
    except subprocess.TimeoutExpired:
        return f"'{app_name}' açılırken zaman aşımı."
    except Exception as e:
        return f"Hata: {e}"
