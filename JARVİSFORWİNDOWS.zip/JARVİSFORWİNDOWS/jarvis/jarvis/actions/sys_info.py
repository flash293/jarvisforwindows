"""
Sistem bilgisi — Windows psutil + WMI/netsh.
Alp Ünlü tarafından yapılmıştır — @alppunlu
"""

import datetime
import subprocess

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False


def sys_info(query: str) -> str:
    query = query.lower().strip()

    results = []

    if query in ("battery", "pil", "all"):
        results.append(_battery())

    if query in ("cpu", "işlemci", "all"):
        results.append(_cpu())

    if query in ("ram", "bellek", "memory", "all"):
        results.append(_ram())

    if query in ("disk", "depolama", "all"):
        results.append(_disk())

    if query in ("time", "saat", "zaman", "all"):
        now = datetime.datetime.now()
        results.append(f"Saat: {now.strftime('%H:%M:%S')}")

    if query in ("date", "tarih", "all"):
        now = datetime.datetime.now()
        results.append(f"Tarih: {now.strftime('%d %B %Y, %A')}")

    if query in ("network", "ağ", "wifi", "all"):
        results.append(_network())

    if not results:
        results.append(
            f"Bilinmeyen sorgu: {query}. battery/cpu/ram/disk/time/date/network/all kullanın."
        )

    return "\n".join(r for r in results if r)


def _battery() -> str:
    if HAS_PSUTIL:
        bat = psutil.sensors_battery()
        if bat:
            status = "Şarj oluyor" if bat.power_plugged else "Pilde"
            return f"Pil: %{bat.percent:.0f} — {status}"
    try:
        out = subprocess.check_output(
            ["powershell", "-NoProfile", "-Command",
             "(Get-CimInstance Win32_Battery).EstimatedChargeRemaining"],
            text=True,
            timeout=5,
            creationflags=subprocess.CREATE_NO_WINDOW,
        ).strip()
        if out.isdigit():
            return f"Pil: %{out}"
    except Exception:
        pass
    return "Pil bilgisi alınamadı (masaüstü veya pil yok)."


def _cpu() -> str:
    if HAS_PSUTIL:
        usage = psutil.cpu_percent(interval=0.5)
        count = psutil.cpu_count(logical=True)
        freq = psutil.cpu_freq()
        freq_str = f", {freq.current:.0f} MHz" if freq else ""
        return f"CPU: %{usage:.1f} kullanım — {count} çekirdek{freq_str}"
    return "CPU bilgisi alınamadı."


def _ram() -> str:
    if HAS_PSUTIL:
        vm = psutil.virtual_memory()
        total = vm.total / (1024**3)
        used = vm.used / (1024**3)
        pct = vm.percent
        return f"RAM: {used:.1f}GB / {total:.1f}GB kullanımda (%{pct:.0f})"
    return "RAM bilgisi alınamadı."


def _disk() -> str:
    if HAS_PSUTIL:
        du = psutil.disk_usage("C:\\")
        total = du.total / (1024**3)
        used = du.used / (1024**3)
        free = du.free / (1024**3)
        return f"Disk (C:): {used:.1f}GB kullanıldı, {free:.1f}GB boş (toplam {total:.1f}GB)"
    try:
        out = subprocess.check_output(
            ["wmic", "logicaldisk", "where", "DeviceID='C:'", "get", "Size,FreeSpace"],
            text=True,
            timeout=5,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        lines = [line.strip() for line in out.splitlines() if line.strip()]
        if len(lines) >= 2:
            return f"Disk: {lines[-1]}"
    except Exception:
        pass
    return "Disk bilgisi alınamadı."


def _network() -> str:
    try:
        out = subprocess.check_output(
            ["netsh", "wlan", "show", "interfaces"],
            text=True,
            timeout=5,
            creationflags=subprocess.CREATE_NO_WINDOW,
            stderr=subprocess.DEVNULL,
        )
        ssid = ""
        signal = ""
        for line in out.splitlines():
            if "SSID" in line and "BSSID" not in line:
                ssid = line.split(":", 1)[-1].strip()
            if "Signal" in line:
                signal = line.split(":", 1)[-1].strip()
        if ssid:
            extra = f" ({signal})" if signal else ""
            return f"WiFi: {ssid} bağlı{extra}"
    except Exception:
        pass

    if HAS_PSUTIL:
        import socket

        addrs = psutil.net_if_addrs()
        for name, entries in addrs.items():
            if "wi" in name.lower() or "wlan" in name.lower():
                for entry in entries:
                    if entry.family == socket.AF_INET:
                        return f"Ağ ({name}): IP {entry.address}"

    try:
        out = subprocess.check_output(
            ["powershell", "-NoProfile", "-Command",
             "(Get-NetIPAddress -AddressFamily IPv4 | Where-Object {$_.InterfaceAlias -notmatch 'Loopback'} | Select-Object -First 1).IPAddress"],
            text=True,
            timeout=5,
            creationflags=subprocess.CREATE_NO_WINDOW,
        ).strip()
        if out:
            return f"Ağ: IP {out}"
    except Exception:
        pass
    return "Ağ bağlantısı bulunamadı."
