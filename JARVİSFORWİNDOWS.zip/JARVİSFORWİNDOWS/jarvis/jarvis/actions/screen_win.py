"""
Windows ekran yakalama — aktif pencere (mss + win32gui).
Alp Ünlü tarafından yapılmıştır — @alppunlu
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path


def _screen_permission_message() -> str:
    return (
        "Ekran analizi icin Windows ekran kaydi izni gerekebilir. "
        "Ayarlar > Gizlilik ve guvenlik > Ekran yakalama bolumunde "
        "Python veya terminal uygulamasina izin ver. "
        "Korumali icerik (DRM) olan pencereler bos gorunebilir."
    )


def capture_active_window() -> tuple[bool, str]:
    try:
        import mss
        import win32gui
        import win32process
    except ImportError as exc:
        return False, f"Ekran modulu yuklu degil: {exc}"

    hwnd = win32gui.GetForegroundWindow()
    if not hwnd:
        return False, "Aktif pencere bulunamadi."

    try:
        if win32gui.IsIconic(hwnd):
            win32gui.ShowWindow(hwnd, 9)  # SW_RESTORE
    except Exception:
        pass

    rect = win32gui.GetWindowRect(hwnd)
    left, top, right, bottom = rect
    width = max(1, right - left)
    height = max(1, bottom - top)

    title = win32gui.GetWindowText(hwnd) or "Aktif pencere"
    owner_name = ""
    try:
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        import psutil

        owner_name = psutil.Process(pid).name()
    except Exception:
        owner_name = ""

    handle = tempfile.NamedTemporaryFile(prefix="jarvis-screen-", suffix=".png", delete=False)
    image_path = Path(handle.name)
    handle.close()

    try:
        with mss.mss() as sct:
            monitor = {"left": left, "top": top, "width": width, "height": height}
            shot = sct.grab(monitor)
            mss.tools.to_png(shot.rgb, shot.size, output=str(image_path))
    except Exception as exc:
        return False, f"Ekran goruntusu alinamadi: {exc}"

    payload = {
        "ok": True,
        "image_path": str(image_path),
        "owner_name": owner_name,
        "window_title": title,
        "bounds": {"left": left, "top": top, "width": width, "height": height},
        "detail": "",
    }
    return True, json.dumps(payload, ensure_ascii=False)
