"""
Windows platform utilities for JARVIS.
Alp Ünlü tarafından yapılmıştır — @alppunlu
"""

from __future__ import annotations

import os
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

if sys.platform != "win32":
    raise ImportError("platform_win is only available on Windows")


def open_url(url: str) -> None:
    try:
        os.startfile(url)  # type: ignore[attr-defined]
    except OSError:
        webbrowser.open(url)


def open_app_by_name(app_name: str) -> tuple[bool, str]:
    name = (app_name or "").strip()
    if not name:
        return False, "Uygulama adı boş."

    if os.path.isfile(name) or name.lower().endswith(".exe"):
        try:
            os.startfile(name)  # type: ignore[attr-defined]
            return True, ""
        except OSError as exc:
            return False, str(exc)

    try:
        subprocess.run(
            ["cmd", "/c", "start", "", name],
            check=False,
            timeout=10,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        return True, ""
    except Exception as exc:
        return False, str(exc)


def copy_to_clipboard(text: str) -> tuple[bool, str]:
    try:
        import pyperclip

        pyperclip.copy(text)
        return True, "ok"
    except Exception:
        pass

    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", f"Set-Clipboard -Value { _ps_quote(text) }"],
            check=True,
            timeout=8,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        return True, "ok"
    except Exception as exc:
        return False, f"Panoya kopyalanamadı: {exc}"


def _ps_quote(value: str) -> str:
    escaped = value.replace("'", "''")
    return f"'{escaped}'"


def send_enter(delay: float = 0.3) -> tuple[bool, str]:
    try:
        import pyautogui

        if delay > 0:
            time.sleep(delay)
        pyautogui.press("enter")
        return True, ""
    except Exception as exc:
        return False, f"Enter gönderilemedi: {exc}"


def hotkey(*keys: str, delay: float = 0.0) -> tuple[bool, str]:
    try:
        import pyautogui

        if delay > 0:
            time.sleep(delay)
        pyautogui.hotkey(*keys)
        return True, ""
    except Exception as exc:
        return False, f"Kısayol gönderilemedi: {exc}"


def type_keys(text: str, interval: float = 0.02) -> tuple[bool, str]:
    try:
        import pyautogui

        pyautogui.write(text, interval=interval)
        return True, ""
    except Exception as exc:
        return False, f"Tuş gönderilemedi: {exc}"


def press_key(key: str, delay: float = 0.0) -> tuple[bool, str]:
    try:
        import pyautogui

        if delay > 0:
            time.sleep(delay)
        pyautogui.press(key)
        return True, ""
    except Exception as exc:
        return False, f"Tuş gönderilemedi: {exc}"


def find_executable(candidates: list[str]) -> str | None:
    import winreg

    for name in candidates:
        path = shutil_which(name)
        if path:
            return path

    search_keys = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"),
    ]
    for hive, base in search_keys:
        for exe_name in candidates:
            try:
                with winreg.OpenKey(hive, base + "\\" + exe_name) as key:
                    value, _ = winreg.QueryValueEx(key, "")
                    if value and os.path.isfile(value):
                        return value
            except OSError:
                continue
    return None


def shutil_which(name: str) -> str | None:
    import shutil

    return shutil.which(name)


def app_exists_win(exe_names: list[str], common_paths: list[Path] | None = None) -> bool:
    if find_executable(exe_names):
        return True
    if common_paths:
        for path in common_paths:
            if path.exists():
                return True
    return False
