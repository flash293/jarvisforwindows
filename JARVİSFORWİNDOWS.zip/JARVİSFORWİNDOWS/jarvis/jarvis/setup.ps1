# JARVIS Windows — Kurulum ve baslatma
# Alp Ünlü tarafından yapılmıştır — @alppunlu

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host ""
Write-Host "╔══════════════════════════════════════╗"
Write-Host "║     J.A.R.V.I.S  Windows Kurulum     ║"
Write-Host "╚══════════════════════════════════════╝"
Write-Host ""

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "Python bulunamadi. https://www.python.org adresinden Python 3.10+ kur." -ForegroundColor Red
    exit 1
}

Write-Host "Sanal ortam olusturuluyor..."
if (-not (Test-Path ".venv")) {
    python -m venv .venv
}

Write-Host "Bagimliliklar yukleniyor..."
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\pip.exe install -r requirements.txt

Write-Host ""
Write-Host "pywin32 post-install..."
& .\.venv\Scripts\python.exe -m pywin32_postinstall -install 2>$null

$configDir = Join-Path $PSScriptRoot "config"
$apiExample = Join-Path $configDir "api_keys.example.json"
$apiTarget = Join-Path $configDir "api_keys.json"
if (-not (Test-Path $apiTarget) -and (Test-Path $apiExample)) {
    Copy-Item $apiExample $apiTarget
    Write-Host "api_keys.json olusturuldu — Gemini API anahtarini ekle."
}

Write-Host ""
Write-Host "JARVIS baslatiliyor..."
& .\.venv\Scripts\python.exe main.py
